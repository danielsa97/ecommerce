<?php


namespace App\Services\Catalog\Brand;

use App\Traits\ChangeGeneralStatusTrait;

class BrandChangeStatusService extends BrandService
{
    use ChangeGeneralStatusTrait;
}
