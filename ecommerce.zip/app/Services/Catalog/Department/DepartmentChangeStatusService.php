<?php


namespace App\Services\Catalog\Department;

use App\Traits\ChangeGeneralStatusTrait;

class DepartmentChangeStatusService extends DepartmentService
{
    use ChangeGeneralStatusTrait;
}
