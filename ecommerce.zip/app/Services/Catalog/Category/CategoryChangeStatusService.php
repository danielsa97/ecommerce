<?php


namespace App\Services\Catalog\Category;

use App\Traits\ChangeGeneralStatusTrait;

class CategoryChangeStatusService extends CategoryService
{
    use ChangeGeneralStatusTrait;
}
