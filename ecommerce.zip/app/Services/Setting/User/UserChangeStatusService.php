<?php


namespace App\Services\Setting\User;

use App\Traits\ChangeGeneralStatusTrait;

class UserChangeStatusService extends UserService
{
    use ChangeGeneralStatusTrait;
}
