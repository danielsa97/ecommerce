<?php


namespace App\Services;

use App\Traits\ImageStorageTrait;

class GetImageService
{
    use ImageStorageTrait;
}
