<span class='badge {{$status === 'Ativo' ? 'badge-success' : 'badge-danger'}}'>{{$status}}</span>
