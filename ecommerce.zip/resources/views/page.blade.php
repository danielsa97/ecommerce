@extends('adminlte::page')
@section('content')
    <page>
        <router-view></router-view>
    </page>
@stop
