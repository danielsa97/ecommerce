<template>
    <b-card :title="title">

    </b-card>
</template>

<script>
    export default {
        name: "FormGroupMultiple",
        props: {
            title: {
                type: String,
                required: false
            }
        }
    }
</script>

<style scoped>

</style>
