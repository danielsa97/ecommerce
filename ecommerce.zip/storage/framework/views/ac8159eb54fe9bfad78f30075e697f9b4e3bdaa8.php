<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-card class="table-responsive">
        <?php echo $userDataTable->table(); ?>

    </b-card>
    <user-manager datatable="user_datatable"></user-manager>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo e($userDataTable->scripts()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/setting/user/index.blade.php ENDPATH**/ ?>