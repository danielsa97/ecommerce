<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-row>
        <b-col>
            <b-card class="table-responsive">
                <?php echo $dataTable->table(['class' => 'table']); ?>

            </b-card>
        </b-col>
    </b-row>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/bom_construtor/resources/views/setting/user/index.blade.php ENDPATH**/ ?>