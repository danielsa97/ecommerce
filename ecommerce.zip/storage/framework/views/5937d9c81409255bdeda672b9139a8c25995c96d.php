<?php $__env->startSection('content_header'); ?>
    <h1>Departamentos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-card>
        <department-manager></department-manager>
    </b-card>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/catalog/department/index.blade.php ENDPATH**/ ?>