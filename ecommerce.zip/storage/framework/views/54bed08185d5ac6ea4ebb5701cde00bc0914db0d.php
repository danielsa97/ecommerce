<?php if((!isset($item['topnav']) || (isset($item['topnav']) && !$item['topnav'])) && (!isset($item['topnav_right']) || (isset($item['topnav_right']) && !$item['topnav_right'])) && (!isset($item['topnav_user']) || (isset($item['topnav_user']) && !$item['topnav_user']))): ?>
    <?php if(is_string($item)): ?>
        <li <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>" <?php endif; ?> class="nav-header"><?php echo e($item); ?></li>
    <?php elseif(isset($item['header'])): ?>
        <li <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>" <?php endif; ?> class="nav-header"><?php echo e($item['header']); ?></li>
    <?php else: ?>
                <li <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>"
                    <?php endif; ?> class="nav-item <?php if(isset($item['submenu'])): ?><?php echo e($item['submenu_class']); ?><?php endif; ?>">
                    <router-link to="<?php echo e($item['url'] ?? '#'); ?>" class="nav-link">
                        <i class="<?php echo e($item['icon'] ?? 'fa fa-arrow-right'); ?> <?php echo e(isset($item['icon_color']) ? 'text-' . $item['icon_color'] : ''); ?>"></i>
                        <p>
                            <?php echo e($item['text']); ?>


                            <?php if(isset($item['submenu'])): ?>
                                <i class="fas fa-angle-left right"></i>
                            <?php endif; ?>
                        </p>
                    </router-link>
                    <?php if(isset($item['submenu'])): ?>
                        <ul class="nav nav-treeview">
                            <?php echo $__env->renderEach('adminlte::partials.menu-item', $item['submenu'], 'item'); ?>
                        </ul>
                    <?php endif; ?>
                </li>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/ecommerce/resources/views/vendor/adminlte/partials/menu-item.blade.php ENDPATH**/ ?>