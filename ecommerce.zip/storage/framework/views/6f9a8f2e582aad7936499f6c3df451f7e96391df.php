<?php $__env->startSection('adminlte_css'); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo $__env->yieldContent('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_data',
(config('adminlte.sidebar_scrollbar_theme', 'os-theme-light') != 'os-theme-light' ? 'data-scrollbar-theme=' . config('adminlte.sidebar_scrollbar_theme')  : '') . ' ' . (config('adminlte.sidebar_scrollbar_auto_hide', 'l') != 'l' ? 'data-scrollbar-auto-hide=' . config('adminlte.sidebar_scrollbar_auto_hide')   : '')); ?>

<?php ( $logout_url = View::getSection('logout_url') ?? config('adminlte.logout_url', 'logout') ); ?>
<?php ( $profile_url = View::getSection('profile_url') ?? config('adminlte.profile_url', 'logout') ); ?>
<?php ( $dashboard_url = View::getSection('dashboard_url') ?? config('adminlte.dashboard_url', 'home') ); ?>

<?php if(config('adminlte.use_route_url', false)): ?>
    <?php ( $logout_url = $logout_url ? route($logout_url) : '' ); ?>
    <?php ( $profile_url = $profile_url ? route($profile_url) : '' ); ?>
    <?php ( $dashboard_url = $dashboard_url ? route($dashboard_url) : '' ); ?>
<?php else: ?>
    <?php ( $logout_url = $logout_url ? url($logout_url) : '' ); ?>
    <?php ( $profile_url = $profile_url ? url($profile_url) : '' ); ?>
    <?php ( $dashboard_url = $dashboard_url ? url($dashboard_url) : '' ); ?>
<?php endif; ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper" id="app">
        <nav
            class="main-header navbar <?php echo e(config('adminlte.classes_topnav_nav', 'navbar-expand-md')); ?> <?php echo e(config('adminlte.classes_topnav', 'navbar-white navbar-light')); ?>">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#"
                       <?php if(config('adminlte.sidebar_collapse_remember')): ?> data-enable-remember="true"
                       <?php endif; ?> <?php if(!config('adminlte.sidebar_collapse_remember_no_transition')): ?> data-no-transition-after-reload="false"
                       <?php endif; ?> <?php if(config('adminlte.sidebar_collapse_auto_size')): ?> data-auto-collapse-size="<?php echo e(config('adminlte.sidebar_collapse_auto_size')); ?>" <?php endif; ?>>
                        <i class="fas fa-bars"></i>
                        <span class="sr-only"><?php echo e(__('adminlte::adminlte.toggle_navigation')); ?></span>
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto <?php if(config('adminlte.layout_topnav') || View::getSection('layout_topnav')): ?>order-1 order-md-3 navbar-no-expand <?php endif; ?>">
                <?php if(Auth::user()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="#"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa fa-fw fa-power-off"></i> <?php echo e(__('adminlte::adminlte.log_out')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e($logout_url); ?>" method="POST"
                              style="display: none;">
                            <?php if(config('adminlte.logout_method')): ?>
                                <?php echo e(method_field(config('adminlte.logout_method'))); ?>

                            <?php endif; ?>
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <aside class="main-sidebar vh-100 <?php echo e(config('adminlte.classes_sidebar', 'sidebar-dark-primary elevation-4')); ?>">
            <a href="<?php echo e($dashboard_url); ?>"
               class="brand-link bg-white text-center <?php echo e(config('adminlte.classes_brand')); ?>">
                <?php if(session('brand')): ?>
                    <img class="img-fluid pl-5 pr-5 pb-2" src="<?php echo e(route('image.index', session('brand'))); ?>"
                         alt="<?php echo config('adminlte.title', '<b>E</b>-Commerce'); ?>">
                <?php else: ?>
                    <span class="brand-text  font-weight-light <?php echo e(config('adminlte.classes_brand_text')); ?>">
                        <?php echo config('adminlte.logo', '<b>E-</b>commerce'); ?>

                    </span>
                <?php endif; ?>

            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <sidebar></sidebar>
                </nav>
            </div>
        </aside>
        <?php echo $__env->yieldContent('content'); ?>
        <?php if (! empty(trim($__env->yieldContent('footer')))): ?>
            <footer class="main-footer">
                <?php echo $__env->yieldContent('footer'); ?>
            </footer>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <script src="<?php echo e(asset('vendor/adminlte/dist/js/adminlte.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    <?php echo $__env->yieldContent('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/vendor/adminlte/page.blade.php ENDPATH**/ ?>