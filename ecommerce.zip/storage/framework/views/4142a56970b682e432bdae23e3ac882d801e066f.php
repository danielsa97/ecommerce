<?php $__env->startSection('content'); ?>
    <page>
        <router-view></router-view>
    </page>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/page.blade.php ENDPATH**/ ?>