<?php $__env->startSection('content_header'); ?>
    <h1>Marcas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-card class="table-responsive">
        <?php echo $brandDataTable->table(); ?>

    </b-card>
    <brand-manager datatable="brand_datatable"></brand-manager>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo e($brandDataTable->scripts()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/catalog/brand/index.blade.php ENDPATH**/ ?>