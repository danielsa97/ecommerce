<?php $__env->startSection('content_header'); ?>
    <h1>Descontos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-card class="table-responsive">
        <?php echo $discountDataTable->table(); ?>

    </b-card>
    <discount-manager datatable="discount_datatable"></discount-manager>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo e($discountDataTable->scripts()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/catalog/discount/index.blade.php ENDPATH**/ ?>