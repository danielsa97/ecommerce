<?php $__env->startSection('content_header'); ?>
    <h1>Categorias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <b-card class="table-responsive">
        <?php echo $categoryDataTable->table(); ?>

    </b-card>
    <category-manager datatable="category_datatable"></category-manager>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo e($categoryDataTable->scripts()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ecommerce/resources/views/catalog/category/index.blade.php ENDPATH**/ ?>