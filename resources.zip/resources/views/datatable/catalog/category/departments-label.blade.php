@foreach($departments as $department)
    <span class="badge badge-primary">
        {{$department}}
    </span>
@endforeach
